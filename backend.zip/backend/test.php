<?php
phpinfo();
// error_reporting(E_ALL);
// ini_set('display_errors', 1);
// // print_r(time()."</br>\n".microtime(TRUE));
// echo 'jsdf';
// echo "\n";
// $r = ['u'=>'g'];
// echo $r['u'];
// echo "\n";
// echo isset($r['v']) ? $r['v'] : 'jrx';
// echo "\n";
// echo isset($r['v']['h']);
// $f = (object)$r;
// print_r(json_encode($f)); echo "\n";
// print_r($f->u); echo "\n";
// print_r($f->v); echo "\n";
// print_r($f->v->h); echo "\n";
// echo "\n";
// $r = ['v'=>'h'];
// echo isset($r['v']) ? $r['v'] : 'jrx';
// echo "\n";
?>
