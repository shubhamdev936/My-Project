// importing modules
const express = require('express')
const app = express()
const mongoose = require('mongoose')
var path = require('path')
const bodyParser = require('body-parser');

app.use(bodyParser.urlencoded({ extended: true }));
mongoose.Promise = global.Promise
mongoose.connect('mongodb://127.0.0.1:27017/jobportal', { useNewUrlParser: true, useUnifiedTopology: true, useFindAndModify: false })
  .then(() => console.log("Database Connected"))
  .catch((error) => console.log(error))

const users = require('./db/models/users')

app.use(express.json())

app.use((req, res, next) => {
  res.header("Access-Control-Allow-Origin", "*")
  res.header("Access-Control-Allow-Method", "GET, POST, HEAD, OPTIONS, PUT, PATCH, DELETE")
  res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept")
  next()
})


app.post('/userlogin', (req, res) => {
  // console.log("My body", req.body)
  users.findOne({
    // username: username,
    email:  req.body.email,
    password: req.body.password
  }).then(user => {
    if (user) {
      console.log(user)
      res.send(user)
    } else {
      res.send("Not Found")
    }
  }).catch((error) => console.log(error))
})

app.post('/useradd', (req, res) => {
  (new users({
    'username': req.body.username,
    'name': req.body.name,
    'email': req.body.email,
    'password': req.body.password,
    'dob': req.body.dob,
    'country': req.body.country,
    'city': req.body.city,
    'position': req.body.position,
  }))
    .save()
    .then((usad) => res.send(usad))
    .catch((error) => console.log(error))
})


// static file add
app.use(express.static(path.join(__dirname, 'public')))

// app.get('/', (req, res) => {
//     res.sendfile('./public/index.html')
// })

var PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  // fs.mkdirSync(AIfolder, { recursive: true });
  console.log("Node Backend Server running on port*: " + PORT);
});