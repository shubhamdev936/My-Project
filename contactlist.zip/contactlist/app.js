// importing modules
var express = require('express')
var mongoose = require('mongoose')
var bodyparser = require('body-parser')
var cors = require('cors')
var path = require('path')

var app = express()

const route = require('./routes/route')

// connect to database mongoDB
mongoose.connect('mongodb://localhost:27017/contactlist')

// on Conenctions
mongoose.connection.on('connect', () => {
    console.log('connected to database mongodb @ 27017')
})

// error to connection database
mongoose.connection.on('error', (err) => {
    if (err) {
        console.log('Error in database to connection:' + err)
    }
})

// define port Number
const port = 3000

// Adding Middleware cors()
app.use(cors())

// Adding body-parser 
app.use(bodyparser.json())

// static file add
 app.use(express.static(path.join(__dirname, 'public')))

// routes
app.use('/api', route)

// testing Server
app.get('/', (req, res) => {
    res.send('Shubham-Sharma')
})

app.listen(port, () => {
    console.log("Server started at port:" + port)
})