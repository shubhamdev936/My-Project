//#region hard codes important
//#region  requires
var express = require('express');
var app = express();
var fs = require('fs');
var path = require('path');

//#region environment setting
process.env.NODE_ENV = 'development';
process.env.DB_HOST = 'localhost';
process.argv.slice(2).forEach(v => {
  if (v.toLowerCase() === '--prod') process.env.NODE_ENV = 'production';
  if (v.toLowerCase().indexOf('--port=') > -1) process.env.PORT = parseInt(v.substr(7));
  if (v.toLowerCase().indexOf('--db=') > -1) process.env.DB_HOST = v.substr(5);
});
//#endregion

var passport = require('passport');
var GoogleStrategy = require('passport-google-oauth').OAuth2Strategy;
var LocalStrategy = require('passport-local').Strategy;
var http = require("http").Server(app);
var cors = require('cors');
var bodyParser = require('body-parser');
var session = require('express-session');
var md5 = require('md5');
var io = require("socket.io")(http);
var sharedSession = require('express-socket.io-session');
var MySQLStore = require('express-mysql-session')(session);

var PORT = process.env.PORT || 3000;
var models_master = require("../../../../edeiticc_master/models")(process.env.DB_HOST);
var models = require('./db/models')(process.env.DB_HOST);
//#endregion

//#region authorisation credentials
var configAuth = {
  googleAuth: {
    clientID: '1028365207083-1v5npp1l3hkqdh6hago9sdjjg2u3spfq.apps.googleusercontent.com',
    clientSecret: 'B_nya2440FvrFS0P0V_PSDjZ',
    callbackURL: 'http://localhost:3000/auth/google/redirect'
  },
}
//#endregion

//#region session config
var sessStoreOpts = {
  host: models_master.config.host,
  port: 3306,
  user: models_master.config.username,
  password: models_master.config.password,
  database: models_master.config.database,
  createDatabaseTable: true,
  schema: {
    tableName: 'sessions',
    columnNames: {
      session_id: 'session_id',
      expires: 'expires',
      data: 'data'
    }
  }
};
var sessionStore = new MySQLStore(sessStoreOpts);
var sess = session({
  secret: 'qURwhKNfOsjgMRfZqrN0OJGERAc2Fcd70GmL64PqemmFhMQUYoZ9LpI3U6Fnv0aFAjbZiKb0xKbt8Kj3kNG883wyJLtkJApsJUMwdf86VueMZX0MJOnEOW2BxQSy0I9xVSTp3wnpNpRSLgkEyOBQDJyMEb52FZL36X3uM4Dmx6dSTSRy77wqK8pUmASSamNrgeBABLau',
  saveUninitialized: true,
  unset: 'destroy',
  resave: false,
  store: sessionStore,
  cookie: {
    secure: false,
    httpOnly: false,
    maxAge: 1000 * 60 * 60 * 24
  }
});
//#endregion

//#region app.use()
// app.use(cors());
app.use(cors({ credentials: true, origin: true }));
app.use(bodyParser.urlencoded({ extended: false }));
app.use(passport.initialize());
app.use(bodyParser.json())
app.use(sess);

app.use(express.static('public'));
app.use(passport.session());
io.use(sharedSession(sess));
//#endregion
//#endregion
//#region strategies
//#region google strategy
passport.serializeUser((user, done) => {
  done(null, user);
});
passport.deserializeUser((user, done) => {
  done(null, user);
});

passport.use(new GoogleStrategy({
  clientID: configAuth.googleAuth.clientID,
  clientSecret: configAuth.googleAuth.clientSecret,
  callbackURL: configAuth.googleAuth.callbackURL
}, async (accessToken, refreshToken, profile, done) => {
  process.nextTick(_ => {
    // console.log(profile.id);
    if (profile.emails[0].verified) {
      let sequelize = models_master.sequelize;
      models_master.users.findOrCreate({
        attributes: [
          'prid',
          [sequelize.fn('REGEXP_REPLACE', sequelize.fn('SUBSTRING_INDEX', sequelize.col('email'), '@', 1), '\\.|_', ' '), 'username'],
          'email'
        ], where: {
          email: profile.emails[0].value,
        }, defaults: {
          prid: 'g' + profile.id,
          email: profile.emails[0].value,
          // password: profile.password.value,
          picture: profile.photos[0].value
        }, raw: true
      }).spread((usr, err) => {
        if (usr === null) {
          console.log('no such user : ', '  TODO enter new user');
          return;
        }
        if (usr.dataValues) usr = {
          prid: usr.dataValues.prid,
          username: usr.dataValues.username || usr.dataValues.email.split('@')[0].replace(/\.|_/g, ' '),

          email: usr.dataValues.email,
        };
        console.log('usr : ', usr);
        usr.DP = profile.photos[0].value;
        return done(null, usr)
      }).error(console.error);
    }
  });
}));
//#endregion
//#endregion

//#region localStrategy
// passport.use(new LocalStrategy(
//   function (req, res, done) {
//     console.log("TESTING", req)
//     models_master.users.findAll({
//       raw: true,
//       attributes: [`prid`, `username`, `email`, `picture`],
//       where: { email: req.body.email, password: req.body.password },
//       logging: true
//     }).spread((lusr, err) => {
//       console.log(lusr)
//       if (lusr === null) {
//         console.log('No Such User Found')
//         return;
//       } console.log('lusr', lusr)
//       res.send(req.body.mode + 'SUCCESS' + JSON.stringify(lusr));
//     })
//   }
// ));

passport.use(new LocalStrategy(
  function (email, password, done) {
    console.log('AAJa Yr', email);
    console.log(password);
    models_master.users.findAll({
      raw: true,
      attributes: [`prid`, `username`, `email`, `picture`],
      where: { email: req.body.email, password: req.body.password },
      logging: true
    }).spread((lusr, err) => {
      console.log(lusr)
      if (lusr === null) {
        console.log('No Such User Found')
        return;
      } console.log('lusr', lusr)
      return done(lusr);
      // res.send(req.body.mode + 'SUCCESS' + JSON.stringify(lusr));
    })
  }
));


//#endregion localStrategy

//#region login get and post requets
app.get('/', (req, res, next) => {
  // req.session.save()
  console.log(req.body)
  res.redirect('http://localhost:4200');
});

// app.post('/', (req, res, next) => {
//   // req.session.save()
//   console.log('Data Accept ',req.body)
//   res.redirect('/LOGIN');
// });

//#region auths
app.get('/auth/google', passport.authenticate('google', { scope: ['profile', 'email'] }));

app.get('/auth/google/redirect', passport.authenticate('google', {
  failureRedirect: '/',
  successRedirect: '/'
}));
//#endregion
//#endregion

//#region local Strategy
app.get('/LOGIN', passport.authenticate('local', { failureRedirect: '/LOGIN' }),
  function (req, res) {
    console.log('Testing', req)
    res.redirect('/');
  });
//#endregion local Strategy

//#region all ajax modes defined here
app.post('/', (req, res) => {
  try {
    let thisUsrPRID;
    let otherUser;
    switch (req.body.mode) {
      //#region ISLOGGEDIN
      case 'ISLOGGEDIN':
        if (req.session.passport === undefined) return res.send(req.body.mode + 'SUCCESS' + JSON.stringify(false));
        let userDets = req.session.passport.user;
        res.send(req.body.mode + 'SUCCESS' + JSON.stringify({ userDets }));
        break;
      //#endregion
      //#region GETGAMEBETWEEN
      case 'GETGAMEBETWEEN':
        if (req.session.passport === undefined) return res.send(req.body.mode + 'SUCCESS' + JSON.stringify(false));
        thisUsrPRID = req.session.passport.user.prid;
        otherUser = roomName2id(req.body.sock);
        var whereLiteral = `(\`sender\`, \`receiver\`) IN (('${otherUser}', '${thisUsrPRID}'), ('${thisUsrPRID}', '${otherUser}'))`;
        models.games.findOne({
          attributes: ['prid', [models.games.sequelize.literal(`IF(\`game_status\`=4, 'game', IF(\`sender\`='${thisUsrPRID}', 'sender', 'receiver'))`), 'st']],
          where: [
            models.games.sequelize.literal(whereLiteral),
            { game_status: [1, 4] }
          ],
          // logging: console.log,
          raw: true
        }).then(game => {
          let usr = {};
          // console.log("gameDets : ", game);
          usr[req.body.username] = {
            st: null,
            sock: req.body.sock,
            prid: null
          };
          if (game) {
            usr[req.body.username].st = game.st
            usr[req.body.username].prid = game.prid
          }
          if (usr[req.body.username] === undefined) return res.send(`${req.body.mode}FAILURESERVER ERROR`);
          res.send(req.body.mode + 'SUCCESS' + JSON.stringify(usr));
        }).error(err => {
          res.send(`${req.body.mode}FAILURESERVER ERROR`);
        });
        break;
      //#endregion
      //#region CHALLENGE_SEND
      case 'CHALLENGE_SEND':
        console.log(req.body)
        if (req.session.passport === undefined) return res.send(req.body.mode + 'FAILURELogin to challenge');
        let fromPRID = req.session.passport.user.prid;
        let toUserPRID = roomName2id(req.body.sock);
        let thisUser = req.session.passport.user.username;
        let thatUser = req.body.username;
        let players = {};
        players[fromPRID] = req.session.passport.user.username;
        players[toUserPRID] = req.body.username;
        if (toUserPRID.length !== fromPRID.length) return res.send(req.body.mode + 'FAILURE' + JSON.stringify(players));
        let gameID = `${(new Date()).getTime()}${fromPRID.substr(1)}${toUserPRID.substr(1)}`;
        models.games.findOrCreate({
          attributes: [
            'prid',
            'sender',
            'game_status',
            'who_can_play',
            'bet_amount',
          ],
          where: [
            models.games.sequelize.literal(`(\`sender\`, \`receiver\`) IN (('${fromPRID}', '${toUserPRID}'),('${toUserPRID}', '${fromPRID}'))`),
            { game_status: [1, 4] }
          ],
          defaults: {
            prid: gameID,
            receiver: toUserPRID,
            sender: fromPRID,
            game_status: 1,
            who_can_play: 3,
            bet_amount: 5000,
            sender_ai: null,
          },
          // logging: console.log,
          raw: true
        }).spread(game => {
          if (game.dataValues) game = game.dataValues;
          let dt2sendTmp = {
            prid: game.prid,
            st: 'game',
            who_can_play: game.who_can_play,
            bet_amount: game.bet_amount
          };
          let dt2send = {
            thisuser: {},
            thatuser: {}
          };
          dt2send.thatuser[thatUser] = dt2sendTmp;
          dt2send.thisuser[thisUser] = dt2sendTmp;
          if (game.game_status === 1) {
            dt2send.thatuser[thatUser].st = toUserPRID === game.sender ? 'sender' : 'receiver';
            dt2send.thisuser[thisUser].st = fromPRID === game.sender ? 'sender' : 'receiver'
          };
          console.log(dt2send);
          io.to(id2roomName(toUserPRID)).emit('challenge', JSON.stringify(dt2send.thatuser));
          res.send(`${req.body.mode}SUCCESS${JSON.stringify(dt2send.thisuser)}`)
        }).error(err => {
          console.error(err);
          res.send(`${req.body.mode}FAILURESERVER ERROR`);
        });
        break;
      //#endregion
      //#region CHALLENGE_REVOKE
      case 'CHALLENGE_REVOKE':
        thisUsrPRID = req.session.passport.user.prid
        otherUser = req.body.usrPRID;
        if (req.session.passport === undefined) return res.send(req.body.mode + 'FAILURELogin to challenge');
        if (req.body.gameid.indexOf(thisUsrPRID.substr(1)) < 0 || req.body.gameid.indexOf(otherUser.substr(1)) < 0) return res.send(req.body.mode + 'FAILURELogin to challenge');
        models.games.update({
          attributes: {
            game_status: 2
          },
          where: {
            prid: req.body.gameid
          },
          logging: console.log,
          raw: true
        }).then(d => {
          console.log(d);
          res.send(req.body.mode + 'SUCCESS' + JSON.stringify(d));
        }).error(console.error);
        break;
      //#endregion
      //#region CHALLENGE_ACCEPT
      case 'CHALLENGE_ACCEPT':
        thisUsrPRID = req.session.passport.user.prid
        otherUser = req.body.usrPRID
        if (req.session.passport === undefined) return res.send(req.body.mode + 'FAILURELogin to challenge');
        models.games.update({
          attributes: {
            game_status: 4
          },
          where: {
            prid: req.body.gameid
          },
          logging: console.log,
          raw: true
        }).then(accept => {
          console.log(accept);
          res.send(req.body.mode + 'SUCCESS' + JSON.stringify(accept));
        }).error(console.error)
        break;
      //#endregion
      //#region CHALLENGE_REJECT
      case 'CHALLENGE_REJECT':
        if (req.session.passport === undefined) return res.send(req.body.mode + 'FAILURELogin to challenge');

        // models.games.
        break;
      //#endregion
      //#region CHALLENGE_REMIND
      case 'CHALLENGE_REMIND':
        if (req.session.passport === undefined) return res.send(req.body.mode + 'FAILURELogin to challenge');

        // models.games.
        break;
      //#endregion

      //#region Login
      // case 'LOGIN':
      //   console.log(req.body)
      //   models_master.users.findOne({
      //     raw: true,
      //     attributes: [`prid`, `username`, `picture`, `email`],
      //     where: { email: req.body.email, password: req.body.password },
      //     logging: true
      //   }).then((ul, err) => {
      //     if (ul === null) {
      //       console.log('No Such User Found')
      //       // res.send(req.body.mode + "False");
      //       res.send(`${req.body.mode}No User Found`);
      //       return;
      //     } console.log('User Found', ul)
      //     res.send(req.body.mode + 'SUCCESS' + JSON.stringify(ul));
      //   })
      //   break;
      //#endregion Login

      //#region Registration
      case 'SIGNUP':
        models_master.users.findOrCreate({
          raw: true,
          attributes: [`prid`, `username`, `password`, `email`],
          where: { email: req.body.email },
          logging: true,
          defaults: {
            prid: 'R' + (new Date()).getTime(),
            username: req.body.username,
            password: req.body.password,
            email: req.body.email
          }
        }).then((sp, err) => {
          if (sp === null) {
            console.log('No Such Users')
            return;
          }
          console.log('sp ', sp)
          res.send(req.body.mode + 'SUCCESS' + JSON.stringify(sp));
        }).error(console.error)
        break;
      //#endregion Registration
      //#region default
      default:
        throw "not valid mode";
      //#endregion
    }
  } catch (error) {
    // console.log("res.headersSent : ", res.headersSent, error);
    // console.log("error");
    res.send(`${req.body.mode}FAILURESERVER ERROR`);
  }
});
//#endregion

app.get('/logout', (req, res, next) => {
  console.log("req.session.passport : ", req.session.passport);
  // req.logOut();
  req.session.destroy(sess);
  res.redirect('http://localhost:4200/');
  // return res.status(200).send();
  next();
});

app.get('/rooms', (req, res, next) => {
  let st = JSON.stringify(io.sockets.adapter.rooms);
  let snd = `
  <pre id="st"></pre>
  <script>
    let dt = ${st};
    console.log(dt);
    document.querySelector('#st').innerHTML = JSON.stringify(${st}, null, 2);//.replace(/\\n/g, "<br />").replace("/  /g","&nbsp;&nbsp;");
  </script>
  `;
  res.send(snd);
  next();
});

//#region room and id manipulation functions
const roomName2id = name => {
  return name.startsWith('r_r_') ? name.substr(4) : false;
};
const id2roomName = name => {
  return 'r_r_' + name;
};
//#endregion

//#region socket server
io.on("connection", socket => {
  let sequelize = models_master.sequelize;
  socket.handshake.session.save();
  console.log("new connection with session : ", socket.handshake.sessionID);

  //#region new socket joining the room after signin
  if (socket.handshake.session.passport) socket.join(id2roomName(socket.handshake.session.passport.user.prid), err => {
    if (err) {
      console.log(err);
      socket.emit('error', 'connection error, the game may or may not work');
      return;
    }
    var usrInterest = socket.handshake.session.passport.user;
    // console.log(usrInterest);
    socket.broadcast.emit('join_leave', { username: usrInterest.username, state: 'joined', sock: id2roomName(usrInterest.prid) });
  });
  //#endregion

  //#region getting list of players that can be played with, for the first time
  /*
    TODO calculate the players to be shown for this guy according to their privacy settings
    socket.emit('pllist', 'LIST OF PEOPLE HE CAN SEE CALCULATED AS ABOVE');
    console.log(Object.keys(io.sockets.adapter.rooms));
  */
  let thisprid = null
  let gameLiteral = "1 = 2";
  if (socket.handshake.session.passport) {
    thisprid = socket.handshake.session.passport.user.prid;
    gameLiteral = `'${thisprid}' in (\`sender\`, \`receiver\`)`;
  }
  let roomsList = []
  Object.keys(io.sockets.adapter.rooms).forEach(r => {
    if (
      r.startsWith('r_r_') &&
      r != id2roomName(thisprid)
    ) roomsList.push(roomName2id(r));
  });
  // console.log("roomsList : ", roomsList);

  models.games.findAll({
    attributes: [
      'game_status',
      'sender',
      'receiver',
      'prid'
    ],
    where: [
      models.games.sequelize.literal(gameLiteral),
      { game_status: [1, 4] }
    ],
    // logging: console.log,
    raw: true
  }).then(games => {
    // console.log("games : ", games);
    let tmpGamesTbl = {};
    games.forEach(g => {
      let otherPRID = g.sender;
      let tmpst = 'receiver';
      if (g.sender === thisprid) {
        otherPRID = g.receiver
        tmpst = 'sender';
      }
      tmpGamesTbl[otherPRID] = {
        prid: g.prid,
        st: 'game'
      }
      if (g.game_status === 1) tmpGamesTbl[otherPRID].st = tmpst;
    });
    models_master.users.findAll({
      attributes: [
        'prid',
        [sequelize.fn('CONCAT', 'r_r_', sequelize.col('prid')), 'sock'],
        [sequelize.fn('REGEXP_REPLACE', sequelize.fn('SUBSTRING_INDEX', sequelize.col('email'), '@', 1), '\\.|_', ' '), 'username']
      ],
      where: {
        prid: roomsList
      },
      // logging: console.log,
      raw: true
    }).then(dt => {
      var pllist = {};
      // console.log("dt : ", dt);
      dt.forEach(s => {
        let prid = s.prid;
        let u = s.username;
        delete s.prid
        delete s.username
        pllist[u] = { ...s, ...{ st: null }, ...tmpGamesTbl[prid] }
      });
      // console.log("pllist : ", pllist);
      socket.emit('pllist', pllist);
    }).error(err => console.log);
  });
  //#endregion

  socket.on('disconnect', function (userdata) {
    console.log('disconnected : ', socket.handshake.sessionID, userdata);
    if (socket.handshake.session.passport) {
      var usrInterest = socket.handshake.session.passport.user;
      if ("room : ", io.sockets.adapter.rooms[usrInterest.prid] === undefined) socket.broadcast.emit('join_leave', { username: usrInterest.username, state: 'left', sock: id2roomName(usrInterest.prid) });
      //TODO after leaving wait 5 seconds then check for existance of room in production
    }
  });
});
//#endregion

http.listen(PORT, () => {
  // fs.mkdirSync(AIfolder, { recursive: true });
  console.log("Node Backend Server running on port*: " + PORT);
});
