module.exports = function (sequelize, DataTypes) {
  return sequelize.define('games', {
    prid: {
      type: DataTypes.STRING,
      defaultValue: sequelize.literal('CURRENT_TIMESTAMP'),
      allowNull: false,
      unique: true
    },
    receiver: {
      type: DataTypes.STRING,
      allowNull: true,
      defaultValue: null
    },
    sender: {
      type: DataTypes.STRING,
      allowNull: true,
      defaultValue: null
    },
    game_status: {
      type: DataTypes.SMALLINT,
      allowNull: true,
      defaultValue: null,
      comment: "1 = Challenge, 2 = challenge Revoked, 3 = Rejected, 4 = Running"
    },
    moves_list: {
      type: DataTypes.STRING,
      allowNull: true,
      defaultValue: null
    },
    who_can_play: {
      type: DataTypes.INTEGER,
      allowNull: false,
      defaultValue: 3,
      comment: "0 = Finished, 1 = Challenge, 2 = challenge Revoked, 3 = Rejected"
    },
    bet_amount: {
      type: DataTypes.INTEGER,
      allowNull: true,
      defaultValue: null
    },
    receiver_ai: {
      type: DataTypes.STRING,
      allowNull: true,
      defaultValue: null
    },
    sender_ai: {
      type: DataTypes.STRING,
      allowNull: true,
      defaultValue: null
    },
    winner: {
      type: DataTypes.STRING,
      allowNull: true,
      defaultValue: null
    },
    tournament: {
      type: DataTypes.STRING,
      allowNull: true,
      defaultValue: null
    },
    createdAt: {
      type: DataTypes.DATE,
      defaultValue: sequelize.literal('CURRENT_TIMESTAMP'),
      allowNull: false
    },
    updatedAt: {
      type: DataTypes.DATE,
      defaultValue: sequelize.literal('CURRENT_TIMESTAMP'),
      allowNull: false
    }
  },
    {
      tableName: 'games',
    });
};