const myporom = (argv1, argv2) => new Promise(resolve => resolve(argv1, argv2));

wait(3000).then(() => console.log('Hello!')); // 'Hello!'